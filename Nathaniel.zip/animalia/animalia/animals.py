class Animalia(object):
    """defines a class of animals. 
    methods descrie the general charactictis of animals"""
    def __init__(self):
        pass

    def feeding(self):
        """returns the """
        pass
    def habitat(self):
        """ returns the habitat type of  an animal"""
        pass
    def skin_covering(self):
        """ returns the skin covering type of  an animal"""
        pass
    def blood_type(self):
        """ returns the blood type of  an animal"""
        pass
    def movement(self):
        """ returns the movement type of  an animal"""
        pass
    def birth_method(self):
        """returns the birth method type of an animal"""
        pass



