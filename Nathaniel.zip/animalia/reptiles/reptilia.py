import animalia.animals as animals
class Reptilia(animals.Animalia):
    def __init__(self):
        super().__init__()

    def birth_method(self):
        return "Laying of Eggs"

    def skin_covering(self):
        return "Scales"

    def blood_type(self):
        return "Cold blooded"








    